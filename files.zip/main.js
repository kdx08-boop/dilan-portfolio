/* ==========================================================
   EDIT HERE – ellaa details-um indha oru object-la dhaan.
   Quotes ("") ullaye irukkura text-a mattum maathunga.
   ========================================================== */
const SITE = {
  name: "Dilan",
  hero: "PORTFOLIO",
  role: "Creative Creator",   // first word bold, rest italic
  photo: "",          // "me.jpg" nu podunga (dots-a maarum). Illana hide aagum.
  about: [
    "I'm Dilan, a passionate student interested in creativity, technology, and innovation.",
    "I enjoy photo editing, exploring IoT projects, learning about financial markets, and developing creative ideas.",
    "I'm also passionate about karate, which has taught me discipline, confidence, and determination. I believe in continuous learning, thinking differently, and turning ideas into reality."
  ],
  services: [
    { title: "Photo Editing",    text: "Creating creative visuals, enhancing photos, color correction, and professional photo manipulation." },
    { title: "IoT Projects",     text: "Exploring smart technologies, developing innovative IoT concepts, and building creative projects." },
    { title: "Trading",          text: "Exploring financial markets, learning market analysis, and understanding trading strategies." },
    { title: "Student",          text: "A passionate learner who is always interested in gaining knowledge, developing new skills, and exploring new opportunities." },
    { title: "Karate Master",    text: "Passionate about martial arts, discipline, self-confidence, and continuous improvement in karate." },
    { title: "Technology",       text: "Exploring modern technologies, discovering new innovations, and learning about the digital world." },
    { title: "Creative Ideas",   text: "Thinking outside the box, generating unique ideas, and transforming imagination into reality." }
  ],
  projects: [
    { title: "Creative Editing Projects", text: "Exploring photo editing, video editing, and creative visual designs.", kind: "Creative", tags: ["Photo","Video"], live: "", code: "", image: "" },
    { title: "IoT Development", text: "Working with smart technology concepts and exploring innovative IoT solutions.", kind: "IoT", tags: ["IoT"], live: "", code: "", image: "" },
    { title: "Technology Experiments", text: "Exploring new technologies, testing ideas, and learning through practical projects.", kind: "Technology", tags: ["Experiments"], live: "", code: "", image: "" },
    { title: "Creative Ideas", text: "Developing unique concepts and turning creative imagination into reality.", kind: "Ideas", tags: ["Concepts"], live: "", code: "", image: "" },
    { title: "More Projects Coming Soon!", text: "New work is on the way.", kind: "Soon", tags: [], live: "", code: "", image: "" }
  ],
  ledText: "CREATE\nMORE",   // dot-matrix section-la varra text (2 lines max)
  contactTitle: "Let's create",
  contactEmphasis: "something extraordinary.",  // orange italic-a varra word
  contactText: "Welcome to my personal portfolio, where creativity meets innovation. Explore my skills, projects, ideas, and passion.",
  email: "hello@example.com",
  resume: "",                 // "resume.pdf" podunga, button varum
  location: "Your city, Country",
  socials: [
    { label: "GitHub", url: "https://github.com/kdx08-boop" }
  ]
};
/* ========================= EDIT END ========================= */

const $ = id => document.getElementById(id);
const el = (t, c, h) => { const e = document.createElement(t); if (c) e.className = c; if (h !== undefined) e.innerHTML = h; return e; };
const esc = s => String(s).replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const still = matchMedia("(prefers-reduced-motion: reduce)").matches;

/* text content */
document.title = SITE.name + " – Portfolio";
$("logo").textContent = SITE.name;
$("intro-name").textContent = SITE.name;
const rw = SITE.role.split(" "); $("role").innerHTML = `<b>${esc(rw.shift())}</b> <span class="serif">${esc(rw.join(" "))}</span>`;
$("h1").textContent = SITE.hero;
$("footer").textContent = "© " + new Date().getFullYear() + " " + SITE.name;
/* photo -> particles: dust assembles into the portrait, repels from the pointer, scatters as you scroll */
let PR = 0; const PM = { x: -999, y: -999 };
addEventListener("pointermove", e => { const c = $("portrait"), q = c.getBoundingClientRect(); PM.x = (e.clientX - q.left) * c.width / q.width; PM.y = (e.clientY - q.top) * c.height / q.height; });
const loadPortrait = src => {
  const run = ++PR, im = new Image(); im.onload = () => {
    const c = $("portrait"), x = c.getContext("2d"), W = 100, H = 133, k = 4.8, t = document.createElement("canvas"); t.width = W; t.height = H;
    const g = t.getContext("2d"), r = Math.max(W / im.width, H / im.height);
    g.drawImage(im, (W - im.width * r) / 2, (H - im.height * r) * .3, im.width * r, im.height * r);
    c.width = Math.round(W * k); c.height = Math.round(H * k); c.hidden = false; x.filter = "none";
    let d; try { d = g.getImageData(0, 0, W, H).data; } catch (e) { x.filter = "grayscale(1) contrast(1.4)"; x.drawImage(t, 0, 0, c.width, c.height); return; }
    const P = [];
    for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
      const n = (j * W + i) * 4, ex = i / W * 2 - 1, ey = j / H * 2 - 1;
      const l = (d[n] * .3 + d[n + 1] * .59 + d[n + 2] * .11) / 255 * Math.max(0, 1 - Math.pow(ex * ex + ey * ey, 1.2));
      if (l > .3) P.push({ hx: i * k, hy: j * k, x: Math.random() * c.width, y: Math.random() * c.height, vx: 0, vy: 0, s: k * (.4 + .6 * l) * .9, sx: (Math.random() - .5) * 600, sy: -Math.random() * 500 });
    }
    let go = still || $("intro").classList.contains("done"); if (!go) setTimeout(() => go = true, 2400);
    const frame = () => {
      if (run !== PR) return;
      const dis = still ? 0 : Math.min(1, scrollY / (innerHeight * .8));
      x.clearRect(0, 0, c.width, c.height);
      if (dis < 1) {
        x.globalAlpha = 1 - dis; x.fillStyle = "#fff";
        for (const p of P) {
          const tx = p.hx + p.sx * dis, ty = p.hy + p.sy * dis;
          if (go) {
            const dx = p.x - PM.x, dy = p.y - PM.y, q = Math.hypot(dx, dy);
            if (q < 60 && !still) { const f = (60 - q) / 60 * 5; p.vx += dx / (q || 1) * f; p.vy += dy / (q || 1) * f; }
            p.vx += (tx - p.x) * .05; p.vy += (ty - p.y) * .05; p.vx *= .82; p.vy *= .82; p.x += p.vx; p.y += p.vy;
          }
          x.fillRect(p.x, p.y, p.s, p.s);
        }
      }
      requestAnimationFrame(frame);
    };
    frame();
  }; im.src = src;
};
SITE.about.forEach(t => { const p = el("p", "", esc(t)); p.style.color = "var(--ink)"; $("about-text").appendChild(p); });
SITE.services.forEach((s, i) => $("svc").appendChild(el("div", "svc", `<i>0${i + 1}</i><h3>${esc(s.title)}</h3><span class="ar" aria-hidden="true">↘</span><p>${esc(s.text)}</p>`)));
SITE.projects.forEach((p, i) => {
  const shot = p.image ? `<img src="${esc(p.image)}" alt="${esc(p.title)} screenshot">` : esc(p.title.slice(0, 2));
  const links = (p.live ? `<a href="${esc(p.live)}" target="_blank" rel="noopener">Live site</a>` : "") + (p.code ? `<a href="${esc(p.code)}" target="_blank" rel="noopener">Source code</a>` : "");
  const w = p.title.split(" "), last = w.pop(), ttl = (w.length ? `<span>${esc(w.join(" "))}</span> ` : "") + `<span class="serif">${esc(last)}</span>`;
  $("projs").appendChild(el("article", "proj", `<div class="shot" style="--c:${(i * 60 + 340) % 360}">${shot}</div><div><p class="eyebrow">0${i + 1} / ${esc(p.kind || "")}</p><h3>${ttl}</h3><p>${esc(p.text)}</p><div class="tags">${p.tags.map(t => `<span>${esc(t)}</span>`).join("")}</div><div class="links">${links}</div></div>`));
});
$("c-title").innerHTML = `<span>${esc(SITE.contactTitle)}</span> <em>${esc(SITE.contactEmphasis)}</em>`;
$("c-text").textContent = SITE.contactText;
$("c-mail").href = "mailto:" + SITE.email;
if (SITE.resume) { $("c-cv").href = SITE.resume; $("c-cv").hidden = false; }
$("c-list").innerHTML = `<div><dt>Email</dt><dd><a href="mailto:${esc(SITE.email)}">${esc(SITE.email)}</a></dd></div><div><dt>Location</dt><dd>${esc(SITE.location)}</dd></div><div><dt>Find me on</dt><dd>${SITE.socials.map(s => `<a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.label)}</a>`).join(" &nbsp; ")}</dd></div>`;

/* edit mode: click "Edit" to change texts and add a photo. Saved in this browser (localStorage). */
const EK = "portfolio-edits-v1";
let ED = {}; try { ED = JSON.parse(localStorage.getItem(EK)) || {}; } catch (e) {}
const persist = () => { try { localStorage.setItem(EK, JSON.stringify(ED)); } catch (e) { alert("Could not save: browser storage is full or blocked."); } };
const EL = [...document.querySelectorAll("#logo,#h1,#role b,#role span,h2:not(#c-title),#about-text p,.svc h3,.svc p,.proj h3 span,.proj div > p:not(.eyebrow),#c-title span,#c-title em,#c-text")];
EL.forEach((e, i) => {
  e.setAttribute("data-e", ""); e.dataset.o = e.textContent;
  const k = i + "|" + e.dataset.o; if (ED.t && ED.t[k] !== undefined) e.textContent = ED.t[k];
  e.addEventListener("input", () => { (ED.t = ED.t || {})[k] = e.textContent; persist(); });
  e.addEventListener("keydown", ev => { if (ev.key === "Enter") { ev.preventDefault(); e.blur(); } });
});
let editing = false;
const setEdit = v => {
  editing = v; document.body.classList.toggle("editing", v); $("ed-toggle").classList.toggle("on", v);
  $("ed-toggle").textContent = v ? "✓ Done" : "✎ Edit"; $("ed-tools").hidden = !v;
  EL.forEach(e => { if (!v) return e.removeAttribute("contenteditable"); try { e.contentEditable = "plaintext-only"; } catch (x) { e.contentEditable = "true"; } });
};
$("ed-toggle").onclick = () => setEdit(!editing);
$("logo").addEventListener("click", ev => { if (editing) ev.preventDefault(); });
const cropTo = (u, fx, cb) => {
  const im = new Image(); im.onload = () => {
    const W = 600, H = 800, sw = Math.min(im.width, im.height * .75), sh = sw * 4 / 3, c = document.createElement("canvas");
    const sx = Math.max(0, Math.min(im.width - sw, fx * im.width - sw / 2)), sy = Math.max(0, (im.height - sh) * .3);
    c.width = W; c.height = H; c.getContext("2d").drawImage(im, sx, sy, sw, sh, 0, 0, W, H); cb(c.toDataURL("image/jpeg", .85));
  }; im.src = u;
};
const showPhoto = () => { if (ED.src) cropTo(ED.src, ED.fx ?? .5, loadPortrait); else if (SITE.photo) loadPortrait(SITE.photo); };
$("ed-photo").onclick = () => $("ed-file").click();
$("ed-file").onchange = e => {
  const f = e.target.files[0]; if (!f) return; const rd = new FileReader();
  rd.onload = () => {
    const im = new Image(); im.onload = () => {
      const k = Math.min(1, 1000 / Math.max(im.width, im.height)), c = document.createElement("canvas"); c.width = im.width * k; c.height = im.height * k;
      c.getContext("2d").drawImage(im, 0, 0, c.width, c.height); ED.src = c.toDataURL("image/jpeg", .85);
      const q = document.createElement("canvas"), qw = 100, qh = Math.max(1, Math.round(100 * im.height / im.width)); q.width = qw; q.height = qh; const qg = q.getContext("2d"); qg.drawImage(im, 0, 0, qw, qh);
      const qd = qg.getImageData(0, 0, qw, qh).data, col = new Array(qw).fill(0); for (let j = 0; j < qh; j++) for (let i = 0; i < qw; i++) { const n = (j * qw + i) * 4, l = (qd[n] + qd[n + 1] + qd[n + 2]) / 765; col[i] += l * l; }
      const win = Math.round(Math.min(qw, qh * .75)); let best = 0, bs = -1; for (let i = 0; i + win <= qw; i++) { let t = 0; for (let k = i; k < i + win; k++) t += col[k]; if (t > bs) { bs = t; best = i; } }
      ED.fx = (best + win / 2) / qw; persist(); showPhoto(); scrollTo({ top: 0, behavior: "smooth" });
    }; im.src = rd.result;
  }; rd.readAsDataURL(f); e.target.value = "";
};
const shift = d => { if (!ED.src) return; ED.fx = Math.max(0, Math.min(1, (ED.fx ?? .5) + d)); persist(); showPhoto(); };
$("ed-l").onclick = () => shift(.06); $("ed-r").onclick = () => shift(-.06);
$("ed-rm").onclick = () => { delete ED.src; delete ED.fx; persist(); location.reload(); };
$("ed-reset").onclick = () => { if (confirm("Reset all edits and the photo?")) { try { localStorage.removeItem(EK); } catch (e) {} location.reload(); } };
showPhoto();

/* intro overlay */
setTimeout(() => $("intro").classList.add("done"), still ? 0 : 2800);

/* sound effects (WebAudio, no files needed). Browser rule: first click/tap-ku appuram dhaan sound varum */
let ac = null, sfx = true;
const beep = (f = 660, d = .08, type = "square") => {
  if (!sfx || !ac) return;
  const o = ac.createOscillator(), g = ac.createGain(), t = ac.currentTime;
  o.type = type; o.frequency.value = f; g.gain.setValueAtTime(.05, t); g.gain.exponentialRampToValueAtTime(.0001, t + d);
  o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t + d);
};
addEventListener("pointerdown", () => { if (!ac) { try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} } }, { once: true });
$("sfx").onclick = () => { sfx = !sfx; $("sfx").textContent = sfx ? "SFX ON" : "SFX OFF"; };
document.addEventListener("click", e => { if (e.target.closest("a,#sfx")) beep(520, .06); });

/* nav: scroll progress + active link */
const links = [...document.querySelectorAll("#nav a")];
addEventListener("scroll", () => {
  const h = document.documentElement;
  $("prog").style.width = (h.scrollTop / (h.scrollHeight - h.clientHeight) * 100) + "%";
}, { passive: true });
const io = new IntersectionObserver(es => es.forEach(e => {
  if (e.isIntersecting) {
    links.forEach(a => a.classList.toggle("on", a.getAttribute("href") === "#" + e.target.id));
    if (window.lastSec && window.lastSec !== e.target.id) { beep(440, .1); setTimeout(() => beep(660, .12), 110); }
    window.lastSec = e.target.id;
  }
}), { rootMargin: "-45% 0px -50% 0px" });
document.querySelectorAll("main > section").forEach(s => io.observe(s));

/* dot-matrix text with pointer repel */
const startDots = () => {
  const c = $("dots"), x = c.getContext("2d"), W = c.width, H = c.height, gap = 9;
  const off = document.createElement("canvas"); off.width = W; off.height = H;
  const o = off.getContext("2d"), lines = SITE.ledText.split("\n").slice(0, 2);
  const size = lines.length > 1 ? 130 : 190;
  o.fillStyle = "#fff"; o.textAlign = "center"; o.textBaseline = "middle"; o.font = `700 ${size}px "Space Grotesk",Arial,sans-serif`;
  lines.forEach((l, i) => o.fillText(l.toUpperCase(), W / 2, H / 2 + (i - (lines.length - 1) / 2) * size * .95, W - 40));
  const d = o.getImageData(0, 0, W, H).data, P = [];
  for (let y = 0; y < H; y += gap) for (let xx = 0; xx < W; xx += gap) if (d[(y * W + xx) * 4 + 3] > 128) P.push({ hx: xx, hy: y, x: xx, y: y, vx: 0, vy: 0 });
  let m = { x: -999, y: -999 };
  const set = e => { const r = c.getBoundingClientRect(), t = e.touches ? e.touches[0] : e; m.x = (t.clientX - r.left) * W / r.width; m.y = (t.clientY - r.top) * H / r.height; };
  c.addEventListener("pointermove", set); c.addEventListener("pointerleave", () => m = { x: -999, y: -999 });
  const draw = () => {
    x.clearRect(0, 0, W, H);
    P.forEach(p => {
      const dx = p.x - m.x, dy = p.y - m.y, dist = Math.hypot(dx, dy);
      if (dist < 70 && !still) { const f = (70 - dist) / 70 * 6; p.vx += dx / dist * f; p.vy += dy / dist * f; }
      p.vx += (p.hx - p.x) * .06; p.vy += (p.hy - p.y) * .06; p.vx *= .82; p.vy *= .82; p.x += p.vx; p.y += p.vy;
      x.fillStyle = "#F2F3F7"; x.beginPath(); x.arc(p.x, p.y, 3, 0, 6.283); x.fill();
    });
    requestAnimationFrame(draw);
  };
  draw();
};
(document.fonts ? document.fonts.ready : Promise.resolve()).then(startDots);

/* 3D scene (three.js) – internet venum, CDN-la irundhu load aagum */
(() => {
  if (!window.THREE) return;
  const cv = $("gl"), R = new THREE.WebGLRenderer({ canvas: cv, antialias: true, alpha: true });
  R.setPixelRatio(Math.min(devicePixelRatio, 2));
  const S = new THREE.Scene(), C = new THREE.PerspectiveCamera(50, 1, .1, 100);
  S.add(new THREE.AmbientLight(0x707590, .8));
  const L1 = new THREE.PointLight(0xFF2E93, 3, 60); L1.position.set(-6, 3, 6);
  const L2 = new THREE.PointLight(0x00E5FF, 2.2, 60); L2.position.set(6, -3, 5);
  S.add(L1, L2);
  const G = new THREE.Group(); S.add(G);
  const core = new THREE.Mesh(new THREE.IcosahedronGeometry(1.9, 1), new THREE.MeshStandardMaterial({ color: 0xaab0c4, metalness: .85, roughness: .28, flatShading: true }));
  const wire = new THREE.Mesh(new THREE.IcosahedronGeometry(2.5, 2), new THREE.MeshBasicMaterial({ color: 0xFF2E93, wireframe: true, transparent: true, opacity: .28 }));
  const ring = new THREE.Mesh(new THREE.TorusGeometry(3.4, .012, 8, 160), new THREE.MeshBasicMaterial({ color: 0x00E5FF, transparent: true, opacity: .7 }));
  ring.rotation.x = 1.2;
  G.add(core, wire, ring);

  const sections = [...document.querySelectorAll("main > section")];
  const key = [[2.6, .2, 1], [-3, .3, .9], [3, 0, 1.1], [-2.8, -.2, .9], [0, 0, 1.6], [2.6, .2, 1]]; // x, y, scale per section
  let mx = 0, my = 0;
  addEventListener("pointermove", e => { mx = e.clientX / innerWidth - .5; my = e.clientY / innerHeight - .5; });
  const ease = still ? 1 : .05;
  const render = t => {
    const h = document.documentElement, p = h.scrollTop / Math.max(1, h.scrollHeight - h.clientHeight);
    let idx = 0; sections.forEach((s, i) => { if (s.getBoundingClientRect().top <= innerHeight / 2) idx = i; });
    const k = key[idx] || key[0], narrow = innerWidth < 760;
    const tx = narrow ? 0 : k[0], ty = narrow ? 1.6 : k[1], ts = narrow ? k[2] * .6 : k[2];
    G.position.x += (tx - G.position.x) * ease; G.position.y += (ty - G.position.y) * ease;
    G.scale.setScalar(G.scale.x + (ts - G.scale.x) * ease);
    G.rotation.y = p * 12 + t * .0002 + mx * .8; G.rotation.x = my * .6 + p * 2;
    wire.rotation.y = -t * .0003; ring.rotation.z = t * .0004;
    C.position.z = 9 - p * 2.5;
    R.render(S, C);
    if (!still) requestAnimationFrame(render);
  };
  const size = () => { R.setSize(innerWidth, innerHeight, false); C.aspect = innerWidth / innerHeight; C.updateProjectionMatrix(); };
  addEventListener("resize", () => { size(); if (still) render(0); });
  size();
  if (still) addEventListener("scroll", () => render(0), { passive: true });
  render(0);
})();
