# Dilan Portfolio

A 3D animated personal portfolio: three.js background, dust-particle photo portrait, dot-text section, in-page text editor.
No build step, no dependencies to install. Plain HTML, CSS and JavaScript.

## Project structure

```
dilan-portfolio/
├── index.html        page markup
├── css/style.css     all styles
├── js/main.js        content (SITE object), 3D scene, animations, edit mode
├── assets/           put your photo / resume / project images here
├── .gitignore
└── README.md
```

## Run locally

```bash
python3 -m http.server 8000
# open http://localhost:8000
```

(Opening `index.html` directly also works. A local server is better when you use photo files from `assets/`.)

## Edit your details

Open `js/main.js` and change the `SITE` object at the top: name, role, about, services, projects, email, location, socials.

- Photo: `photo: "assets/me.jpg"`
- Resume button: `resume: "assets/resume.pdf"`
- Project image: `image: "assets/project1.png"`

You can also click **Edit** on the live page to change texts and add a photo. Those edits are saved only in that browser (localStorage), so put permanent changes in `SITE`.

## Put it on GitHub

```bash
git init
git add .
git commit -m "Add portfolio website"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

## Host it free with GitHub Pages

1. Repo > **Settings** > **Pages**
2. Source: **Deploy from a branch**, branch **main**, folder **/ (root)** > Save
3. Your site goes live at `https://<your-username>.github.io/<repo-name>/`

Other free options: Cloudflare Pages, Netlify (drag and drop the folder).

## Tech

three.js r128 (CDN), Google Fonts (Space Grotesk, Inter, Outfit, Instrument Serif), WebAudio for the sound effects.
